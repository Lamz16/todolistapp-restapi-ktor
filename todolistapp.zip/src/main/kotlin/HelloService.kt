package com.lamz

fun interface HelloService {
    fun sayHello()
}
