rootProject.name = "todolistapp"
